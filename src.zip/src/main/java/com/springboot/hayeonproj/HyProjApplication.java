package com.springboot.hayeonproj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HyProjApplication {

	public static void main(String[] args) {
		SpringApplication.run(HyProjApplication.class, args);
	}

}
